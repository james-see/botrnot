# botrnot
Bot or Not detector

## WIP!

`pip3 install botrnot`

## Usage

You can run `botrnot -h` and it shows the following:

```
$ botrnot -h
usage: botrnot [-h] [-u USERNAME] [-n] [-v] [-j]

collects and processes twitter data example: botrnot -u jamescampbell

optional arguments:
  -h, --help            show this help message and exit
  -u USERNAME, --user USERNAME
                        username to evaluate (default: jamescampbell)
  -n, --no-logo         dont display logo (default False) (default: False)
  -v, --verbose         print more things out about search (default: False)
  -j, --json            save tweets out to json file (default: False)
```
